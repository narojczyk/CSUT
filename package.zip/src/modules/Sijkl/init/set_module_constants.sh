#!/bin/bash

# Constant settings
msgItemFormat="  %-40s\t%s"

cacheInfo="local_cache.info"
# gnupltdata="merged_structure_input.csv"

gpltMinimalX="5*10**3"

inspectForExtreemes="inspect_for_extreemes.py"

#!/bin/bash

# Define and declare additional environment variables for this script
#   directories
INITIALS="$CORE/init"
UTILS="$CORE/utils"

script_dirs=( INITIALS UTILS )



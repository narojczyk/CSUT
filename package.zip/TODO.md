* optimize csut to plot selected data sets (structures)
